"""Download real published-edition cover JPGs from Open Library. Run: pip install requests; python download_openlibrary.py"""
import json,requests,time,pathlib
books=json.load(open('books.json',encoding='utf-8'))
out=pathlib.Path('real_covers');out.mkdir(exist_ok=True)
for b in books:
 try:
  data=requests.get('https://openlibrary.org/search.json',params={'title':b['title'],'author':b['author'],'limit':5},timeout=20).json()
  docs=data.get('docs',[])
  title=b['title'].lower().strip()
  matches=[d for d in docs if d.get('title','').lower().strip()==title and 'cover_i' in d]
  if not matches: matches=[d for d in docs if 'cover_i' in d]
  if not matches: print('NO COVER:',b['id'],b['title']);continue
  cover_id=matches[0]['cover_i']
  r=requests.get(f'https://covers.openlibrary.org/b/id/{cover_id}-L.jpg',timeout=25);r.raise_for_status()
  if len(r.content)<2000:raise ValueError('Missing or small cover image')
  (out/f'book-{b["id"]:03}.jpg').write_bytes(r.content)
  print(b['id'],b['title'],'OK')
  time.sleep(.15)
 except Exception as e: print('ERROR:',b['id'],str(e))
